//
//  AdimoroSdk.h
//  AdimoroSdk
//
//  Created by Apple on 23/03/16.
//  Copyright © 2016 Apple. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface AdimoroSdk : NSObject

+(NSMutableDictionary *)getUserCredentials;
+(BOOL)storeUserCredentials:(NSMutableDictionary *)userCredentialsDict;
@end
