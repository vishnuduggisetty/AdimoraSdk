//
//  AdimoraEntity.h
//  AdimoroSdk
//
//  Created by Apple on 23/03/16.
//  Copyright © 2016 Apple. All rights reserved.
//

#import <CoreData/CoreData.h>
#import <Foundation/Foundation.h>

@interface AdimoraEntity : NSManagedObject

@property (nonatomic, retain) NSString * id;
@property (nonatomic, retain) NSString * firstName;
@property (nonatomic, retain) NSString * lastName;

@end
