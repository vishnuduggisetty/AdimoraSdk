//
//  AdimoraEntity.m
//  AdimoroSdk
//
//  Created by Apple on 23/03/16.
//  Copyright © 2016 Apple. All rights reserved.
//

#import "AdimoraEntity.h"

@implementation AdimoraEntity

@dynamic id;
@dynamic firstName;
@dynamic lastName;

@end
