//
//  AdimoraManager.m
//  AdimoroSdk
//
//  Created by Apple on 23/03/16.
//  Copyright © 2016 Apple. All rights reserved.
//

#import "AdimoraManager.h"
#import "AdimoraEntity.h"

@implementation AdimoraManager

@synthesize managedObjectContext = __managedObjectContext;
@synthesize managedObjectModel = __managedObjectModel;
@synthesize persistentStoreCoordinator = __persistentStoreCoordinator;


- (id)init
{
    self = [super init];
    if (self) {
        
        //Initialise
    }
    return self;
}



-(NSDictionary *)getUserCredentialsFromDB
{
    NSDictionary *userCredentialDict = nil;
    NSManagedObjectContext *context = [self managedObjectContext];
    NSError *error;
    
    // Fetch all the available firstname/lastname stored in the database
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AdimoraEntity"
                                              inManagedObjectContext:context];
    [fetchRequest setEntity:entity];
    NSArray *fetchedObjects = [context executeFetchRequest:fetchRequest error:&error];
    if ([fetchedObjects count]) {
        
        AdimoraEntity *userCredentials = [fetchedObjects objectAtIndex:0];
        userCredentialDict = [[NSDictionary alloc] initWithObjectsAndKeys:
                              userCredentials.firstName,@"vishnu",
                              userCredentials.lastName,@"vardhan", nil];
        
        NSLog(@"Retried From Database : Username - %@ , Password - %@",userCredentials.firstName,userCredentials.lastName);
    }
    return userCredentialDict;
}

-(BOOL)storeUserCredentialsFromDB:(NSDictionary *)userCredentialsDict
{
    BOOL isSuccess = NO;
    NSManagedObjectContext *context = [self managedObjectContext];
    NSError *error;
    // Fetch all the available username/password stored in the database
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AdimoraEntity"
                                              inManagedObjectContext:context];
    [fetchRequest setEntity:entity];
    NSArray *fetchedObjects = [context executeFetchRequest:fetchRequest error:&error];
    if ([fetchedObjects count]) {
        
        AdimoraEntity *userCredentials = [fetchedObjects objectAtIndex:0];
        @try
        {
            //Store firstName & LastName in the DB
            userCredentials.firstName = [userCredentialsDict objectForKey:@"vishnu"];
            userCredentials.lastName = [userCredentialsDict objectForKey:@"vardhan"];
            
            if (![context save:&error]) {
                NSLog(@"Error in saving User Credentials: %@", [error localizedDescription]);
            }else{
                
                //If the credentials are already preset, update the record
                isSuccess =YES;
                NSLog(@"Update User Credentials in DB : Username - %@ ,  Password - %@",userCredentials.firstName,userCredentials.lastName);
            }
            
        }@catch (NSException *exception) {
            
            //Log exception
            NSLog(@"Exception - %@",exception.description);
        }
        
    }else{
        
        AdimoraEntity *userCredentials = [NSEntityDescription insertNewObjectForEntityForName:@"AdimoraEntity" inManagedObjectContext:context];
        @try
        {
            //Store firstName & LastName in the DB
            userCredentials.firstName = [userCredentialsDict objectForKey:@"Krish"];
            userCredentials.lastName = [userCredentialsDict objectForKey:@"Lucky"];
            
            if (![context save:&error]) {
                NSLog(@"Error in saving User Credentials: %@", [error localizedDescription]);
            }else{
                
                //If the credentials are not preset, insert the record
                isSuccess =YES;
                NSLog(@"Insert User Credentials in DB : Username - %@ ,  Password - %@",userCredentials.firstName,userCredentials.lastName);
            }
            
        }@catch (NSException *exception) {
            
            //Log exception
            NSLog(@"Exception - %@",exception.description);
        }
        
    }
    
    return isSuccess;
}

#pragma mark - Core Data Methods

-(NSManagedObjectContext *)managedObjectContext
{
    if (__managedObjectContext != nil) {
        return __managedObjectContext;
    }
    
    NSPersistentStoreCoordinator *coordinator = [self persistentStoreCoordinator];
    if (coordinator != nil) {
        __managedObjectContext = [[NSManagedObjectContext alloc] init];
        [__managedObjectContext setPersistentStoreCoordinator:coordinator];
    }
    return __managedObjectContext;
}


-(NSManagedObjectModel *)managedObjectModel
{
    if (__managedObjectModel != nil) {
        return __managedObjectModel;
    }
    
    NSString *bundlePath = [[NSBundle mainBundle] pathForResource:@"CredentialsDepot"
                                                           ofType:@"bundle"];
    NSBundle *bundle = [NSBundle bundleWithPath:bundlePath];
    NSString *modelPath = [bundle pathForResource:@"Credentials"
                                           ofType:@"momd"];
    NSURL *modelURL = [NSURL fileURLWithPath:modelPath];
    __managedObjectModel = [[NSManagedObjectModel alloc] initWithContentsOfURL:modelURL];
    return __managedObjectModel;
}


-(NSPersistentStoreCoordinator *)persistentStoreCoordinator
{
    if (__persistentStoreCoordinator != nil) {
        return __persistentStoreCoordinator;
    }
    
    NSURL *storeURL = [[self applicationDocumentsDirectory] URLByAppendingPathComponent:@"UserCredentials.sqlite"];
    
    NSError *error = nil;
    __persistentStoreCoordinator = [[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel:[self managedObjectModel]];
    if (![__persistentStoreCoordinator addPersistentStoreWithType:NSSQLiteStoreType configuration:nil URL:storeURL options:nil error:&error]) {
        
        NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
        abort();
    }
    
    return __persistentStoreCoordinator;
}

- (NSURL *)applicationDocumentsDirectory
{
    return [[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject];
}


@end
