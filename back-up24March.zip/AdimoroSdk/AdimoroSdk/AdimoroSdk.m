//
//  AdimoroSdk.m
//  AdimoroSdk
//
//  Created by Apple on 23/03/16.
//  Copyright © 2016 Apple. All rights reserved.
//

#import "AdimoroSdk.h"
#import "AdimoraManager.h"
@implementation AdimoroSdk


+(NSString *) signUp :(NSString *) deviceId :(NSString *) userFirstName :(NSString *) userLastName{
    NSLog(@"device:::%@",deviceId);
    return deviceId;
}

+(NSDictionary *)getUserCredentials
{
    AdimoraManager *credentialManager = [[AdimoraManager alloc] init];
    return [credentialManager getUserCredentialsFromDB];
}

+(BOOL)storeUserCredentials:(NSDictionary *)userCredentialsDict
{
    AdimoraManager *credentialManager = [[AdimoraManager alloc] init];
    return [credentialManager storeUserCredentialsFromDB:userCredentialsDict];
}


@end
