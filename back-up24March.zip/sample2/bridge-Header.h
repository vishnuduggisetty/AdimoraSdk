//
//  bridge-Header.h
//  sample2
//
//  Created by Apple on 24/03/16.
//  Copyright © 2016 Apple. All rights reserved.
//

#import "AdimoroSdk.h"
#ifndef bridge_Header_h
#define bridge_Header_h


#endif /* bridge_Header_h */
