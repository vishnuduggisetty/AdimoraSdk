//
//  ViewController.swift
//  sample2
//
//  Created by Apple on 24/03/16.
//  Copyright © 2016 Apple. All rights reserved.
//

import UIKit
import Foundation

class AdimoraSignUp: NSObject {
    var deviceId:String
    var firstName:String
    var lastName:String
    
    init?(deviceId:String, userFirstName:String, userLastName:String) {
        self.deviceId = deviceId
        self.firstName = userFirstName
        self.lastName = userLastName
        super.init()
        if deviceId.isEmpty{
            return nil
        }
    }
    
}




class ViewController: UIViewController {
    var someDict:Dictionary<String,NSObject> = [:]
 
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        //AdimoroSdk.signUp(<#T##deviceId: String!##String!#>, <#T##userFirstName: String!##String!#>, <#T##userLastName: String!##String!#>)
        let val = AdimoroSdk.signUp("1234", "vishnu", "var")
        
        print(val)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func isRegistrationSuccess() -> Bool {
        if let k = someDict as? NSDictionary{
          savearray(k)
        }
        return true
        //return AdimoroSdk.storeUserCredentials(dataDict)
    }
    
    func savearray(arr:NSDictionary){
        print(arr)
        if let k = arr as? NSDictionary{
            if let n = k["Three"] as? String{
                print(n)
            }
        }    }
    
}

